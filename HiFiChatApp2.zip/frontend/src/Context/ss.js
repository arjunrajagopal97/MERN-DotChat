import React from "react";

const ss = () => {
  return (
    <div>
      <h1>Voice Call</h1>
    </div>
  );
};

export default ss;
